package pt.iade.alojate.dto.response;

public class EstudanteAuthResponse extends AuthResponse {
    private EstudanteResponse estudanteData;

    public EstudanteAuthResponse(String username, String email, String type) {

        super(username, email, type);
    }

    public EstudanteResponse getEstudanteData() {

        return estudanteData;
    }

    public void setEstudanteData(EstudanteResponse estudanteData) {

        this.estudanteData = estudanteData;
    }
}
