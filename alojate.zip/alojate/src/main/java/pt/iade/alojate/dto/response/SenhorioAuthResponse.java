package pt.iade.alojate.dto.response;

public class SenhorioAuthResponse extends AuthResponse {

    private SenhorioResponse senhorioData;

    public SenhorioAuthResponse(String nome, String email, String telefone) {
        super(nome, email, telefone);
    }

    public SenhorioResponse getSenhorioData() {
        return senhorioData;
    }

    public void setSenhorioData(SenhorioResponse senhorioData) {
        this.senhorioData = senhorioData;
    }
}
