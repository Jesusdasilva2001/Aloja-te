package pt.iade.alojate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pt.iade.alojate.models.Senhorio;
import pt.iade.alojate.models.Utilizador;

import java.util.Optional;

public interface UtilizadorRepository extends JpaRepository<Utilizador, Long> {

    Optional<Utilizador> findByEmail(String email);
    Optional<Utilizador> findByUsername(String username);
    Optional<Utilizador> findByPassword(String password);
    Optional<Utilizador> findByType(String type);
}