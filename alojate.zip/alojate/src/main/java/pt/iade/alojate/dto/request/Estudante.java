package pt.iade.alojate.dto.request;

public class Estudante {

    private String nome;

    private String username;
    private String password;
    private String email;
    private int telefone;
    private String passport;
    private String cartaoDeCidadao;
    private String dataDeNascimento;

    public Estudante() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {

        this.nome = nome;
    }

    public String getEmail() {

        return email;
    }

    public void setEmail(String email) {

        this.email = email;
    }

    public long getTelefone() {

        return telefone;
    }

    public void setTelefone(int telefone) {

        this.telefone = telefone;
    }

    public String getPassport() {

        return passport;
    }

    public void setPassport(String passport) {

        this.passport = passport;
    }

    public String getCartaoDeCidadao() {
        return cartaoDeCidadao;
    }

    public void setCartaoDeCidadao(String cartaoDeCidadao) {
        this.cartaoDeCidadao = cartaoDeCidadao;
    }

    public String getDataDeNascimento() {
        return dataDeNascimento;
    }

    public void setDataDeNascimento(String dataDeNascimento) {
        this.dataDeNascimento = dataDeNascimento;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
