package pt.iade.alojate.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pt.iade.alojate.dto.UserType;
import pt.iade.alojate.dto.response.ErrorResponse;
import pt.iade.alojate.dto.response.SenhorioResponse;
import pt.iade.alojate.dto.response.SuccessResponse;
import pt.iade.alojate.models.Senhorio;
import pt.iade.alojate.models.Utilizador;
import pt.iade.alojate.repository.SenhorioRepository;
import pt.iade.alojate.repository.UtilizadorRepository;

@RestController
@RequestMapping("/api/senhorio")
public class SenhorioController {
    private SenhorioRepository senhorioRepository;
    private UtilizadorRepository utilizadorRepository;

    public SenhorioController(SenhorioRepository senhorioRepository, UtilizadorRepository utilizadorRepository) {
        this.senhorioRepository = senhorioRepository;
        this.utilizadorRepository = utilizadorRepository;
    }

    @PostMapping
    public ResponseEntity<?> save(@RequestBody pt.iade.alojate.dto.request.Senhorio senhorio) {

        var s = this.senhorioRepository.findByEmail(senhorio.getEmail());

        if (s.isPresent()) {
            var errorResponse = new ErrorResponse();
            errorResponse.setStatus(400);
            errorResponse.setMessage("Email registrado, tente um outro!");
            return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);
        }

        if (senhorio.getTelefone() >= 10e8) {
            var errorResponse = new ErrorResponse();
            errorResponse.setStatus(400);
            errorResponse.setMessage("Número não pode ter mais de 9 digitos!");
            return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);
        }

        s = this.senhorioRepository.findByTelefone(senhorio.getTelefone());

        if (s.isPresent()) {
            var errorResponse = new ErrorResponse();
            errorResponse.setStatus(400);
            errorResponse.setMessage("Número registrado, tente um outro!");
            return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);
        }

        this.senhorioRepository.save(new Senhorio(
                senhorio.getNome(),
                senhorio.getEmail(),
                senhorio.getTelefone()
        ));

        this.utilizadorRepository.save(
                new Utilizador(
                        senhorio.getUsername(),
                        senhorio.getPassword(),
                        senhorio.getEmail(),
                        UserType.SENHORIO.name()
                )
        );


        var successResponse = new SuccessResponse();
        successResponse.setStatus(HttpStatus.OK.value());
        successResponse.setMessage("Senhorio registrado com sucesso!");
        return ResponseEntity.ok().body(successResponse);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> find(@PathVariable Long id) {
        var senhorio = this.senhorioRepository.findById(id);

        if (!senhorio.isPresent()) {
            var errorResponse = new ErrorResponse();
            errorResponse.setStatus(HttpStatus.NOT_FOUND.value());
            errorResponse.setMessage("Senhorio não encontrado");
            return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);
        }

        var senhorioResponse = new SenhorioResponse();
        senhorioResponse.setId(senhorio.get().getId());
        senhorioResponse.setNome(senhorio.get().getNome());
        senhorioResponse.setEmail(senhorio.get().getEmail());
        senhorioResponse.setTelefone(senhorio.get().getTelefone());

        return ResponseEntity.ok().body(senhorioResponse);
    }

}
