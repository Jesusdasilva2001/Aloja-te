package pt.iade.alojate.dto.response;

public class ErrorResponse extends StatusResponse {

}
