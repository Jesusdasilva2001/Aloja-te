package pt.iade.alojate.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pt.iade.alojate.dto.UserType;
import pt.iade.alojate.dto.response.ErrorResponse;
import pt.iade.alojate.dto.response.EstudanteResponse;
import pt.iade.alojate.dto.response.SuccessResponse;
import pt.iade.alojate.models.Estudante;
import pt.iade.alojate.models.Utilizador;
import pt.iade.alojate.repository.EstudanteRepository;
import pt.iade.alojate.repository.UtilizadorRepository;

@RestController
@RequestMapping ("/api/estudante")
public class EstudanteController {
    private EstudanteRepository estudanteRepository;
    private UtilizadorRepository utilizadorRepository;


    public EstudanteController(EstudanteRepository estudanterepository , UtilizadorRepository utilizadorRepository){
        this.estudanteRepository = estudanterepository;
        this.utilizadorRepository = utilizadorRepository;
    }

    @PostMapping
    public ResponseEntity<?> save(@RequestBody pt.iade.alojate.dto.request.Estudante estudanteRequest) {

        var estudante =  this.estudanteRepository.findByEmail(estudanteRequest.getEmail());

        if (estudante.isPresent()) {
            var errorResponse = new ErrorResponse();
            errorResponse.setStatus(400);
            errorResponse.setMessage("Email registrado, tente um outro!");
            return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);
        }

        estudante = this.estudanteRepository.findByPassport(estudanteRequest.getPassport());
        if (estudante.isPresent()) {
            var errorResponse = new ErrorResponse();
            errorResponse.setStatus(400);
            errorResponse.setMessage("Passport registrado, tente um outro!");
            return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);
        }

        if (estudanteRequest.getTelefone() >= 10e8) {
            var errorResponse = new ErrorResponse();
            errorResponse.setStatus(400);
            errorResponse.setMessage("Número não pode ter mais de 9 digitos!");
            return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);
        }

        estudante = this.estudanteRepository.findByCartaoDeCidadao(estudanteRequest.getCartaoDeCidadao());

        if (estudante.isPresent()) {
            var errorResponse = new ErrorResponse();
            errorResponse.setStatus(400);
            errorResponse.setMessage("Carta de cidadao registrado, tente um outro!");
            return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);
        }

        estudante = this.estudanteRepository.findByTelefone(estudanteRequest.getTelefone());

        if (estudante.isPresent()) {
            var errorResponse = new ErrorResponse();
            errorResponse.setStatus(400);
            errorResponse.setMessage("Número registrado, tente um outro!");
            return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);
        }

        var user = this.utilizadorRepository.findByEmail(estudanteRequest.getUsername());
        if (user.isPresent()) {
            var errorResponse = new ErrorResponse();
            errorResponse.setStatus(400);
            errorResponse.setMessage("Usúario com nome " + estudanteRequest.getUsername() + " registrado, tente um outro!");
            return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);
        }

        user = this.utilizadorRepository.findByEmail(estudanteRequest.getEmail());
        if (user.isPresent()) {
            var errorResponse = new ErrorResponse();
            errorResponse.setStatus(400);
            errorResponse.setMessage("Usúario com email " + estudanteRequest.getEmail() + " registrado, tente um outro!");
            return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);
        }


        this.estudanteRepository.save(new Estudante(
                        estudanteRequest.getNome(),
                        estudanteRequest.getEmail(),
                        estudanteRequest.getTelefone(),
                        estudanteRequest.getPassport(),
                        estudanteRequest.getCartaoDeCidadao(),
                        estudanteRequest.getDataDeNascimento()

                )
        );

        this.utilizadorRepository.save(
                new Utilizador(
                        estudanteRequest.getUsername(),
                        estudanteRequest.getPassword(),
                        estudanteRequest.getEmail(),
                        UserType.ESTUDANTE.name()
                )
        );

        var successResponse = new SuccessResponse();
        successResponse.setStatus(HttpStatus.OK.value());
        successResponse.setMessage("Estudante registrado com sucesso!");
        return ResponseEntity.ok().body(successResponse);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> find(@PathVariable Long id) {
        var estudante = this.estudanteRepository.findById(id);

        if (!estudante.isPresent()) {
            var errorResponse = new ErrorResponse();
            errorResponse.setStatus(HttpStatus.NOT_FOUND.value());
            errorResponse.setMessage("Estudante não encontrado");
            return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);
        }

        var estudanteResponse = new EstudanteResponse();
        estudanteResponse.setId(estudante.get().getId());
        estudanteResponse.setNome(estudante.get().getNome());
        estudanteResponse.setEmail(estudante.get().getEmail());
        estudanteResponse.setTelefone(estudante.get().getTelefone());
        estudanteResponse.setCartaodecidadao(estudante.get().getCartaoDeCidadao());

        return ResponseEntity.ok().body(estudanteResponse);
    }
}
