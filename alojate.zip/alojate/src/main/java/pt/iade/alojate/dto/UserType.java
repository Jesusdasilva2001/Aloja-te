package pt.iade.alojate.dto;


public enum UserType {
    ESTUDANTE,
    SENHORIO;


}
