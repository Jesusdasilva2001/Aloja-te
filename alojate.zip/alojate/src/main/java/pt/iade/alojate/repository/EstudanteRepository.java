package pt.iade.alojate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pt.iade.alojate.models.Estudante;

import java.util.Optional;

public interface EstudanteRepository extends JpaRepository<Estudante, Long> {

    Optional<Estudante> findByNome(String nome);
    Optional<Estudante> findByEmail(String email);
    Optional<Estudante> findByTelefone(Long telefone);

    Optional<Estudante> findByPassport(String passport);

    Optional<Estudante> findByCartaoDeCidadao(String cartaoDeCidadao);

    Optional<Estudante> findByDataDeNascimento(String dataDeNascimento);

}
