package pt.iade.alojate.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "Estudante")
public class Estudante {


    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Long id;
    @Column(name = "nome")
    private String nome;
    @Column(name = "email")
    private String email;
    @Column(name = "telefone")
    private Long telefone;

    @Column(name = "passport")
    private String passport;

    @Column(name = "cartaodecidadao")
    private String cartaoDeCidadao;

    @Column (name = "datadenascimento")
    private String dataDeNascimento;

    public Estudante(String nome, String email, Long telefone, String passport, String cartaoDeCidadao, String dataDeNascimento) {
        this.nome = nome;
        this.email = email;
        this.telefone = telefone;
        this.passport = passport;
        this.cartaoDeCidadao = cartaoDeCidadao;
        this.dataDeNascimento = dataDeNascimento;
    }

    public Estudante() {
    }

    public Long getId() {

        return id;
    }

    public void setId(Long id) {

        this.id = id;
    }

    public String getNome() {

        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {

        return email;
    }

    public void setEmail(String email) {

        this.email = email;
    }

    public Long getTelefone() {

        return telefone;
    }

    public void setTelefone(Long telefone) {

        this.telefone = telefone;
    }

    public String getPassport() {

        return passport;
    }

    public void setPassport(String passport) {

        this.passport = passport;
    }

    public String getCartaoDeCidadao() {
        return cartaoDeCidadao;
    }

    public void setCartaoDeCidadao(String cartaoDeCidadao) {
        this.cartaoDeCidadao = cartaoDeCidadao;
    }

    public String getDataDeNascimento() {
        return dataDeNascimento;
    }

    public void setDataDeNascimento(String dataDeNascimento) {
        this.dataDeNascimento = dataDeNascimento;
    }
}
