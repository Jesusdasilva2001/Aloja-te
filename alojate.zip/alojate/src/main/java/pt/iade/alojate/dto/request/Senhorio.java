package pt.iade.alojate.dto.request;

public class Senhorio {
    private String nome;
    private String email;
    private Long telefone;
    private String username;
    private String password;


    public Senhorio() {
    }

    public String getNome() {

        return nome;
    }

    public void setNome(String nome) {

        this.nome = nome;
    }

    public String getEmail() {

        return email;
    }

    public void setEmail(String email) {

        this.email = email;
    }

    public Long getTelefone() {

        return telefone;
    }

    public void setTelefone(Long telefone) {

        this.telefone = telefone;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
