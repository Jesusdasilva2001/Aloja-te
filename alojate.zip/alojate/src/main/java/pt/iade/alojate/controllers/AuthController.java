package pt.iade.alojate.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pt.iade.alojate.dto.UserType;
import pt.iade.alojate.dto.request.Utilizador;
import pt.iade.alojate.dto.response.*;
import pt.iade.alojate.repository.EstudanteRepository;
import pt.iade.alojate.repository.SenhorioRepository;
import pt.iade.alojate.repository.UtilizadorRepository;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private UtilizadorRepository utilizadorRepository;
    private SenhorioRepository senhorioRepository;

    private EstudanteRepository estudanteRepository;

    public AuthController(UtilizadorRepository utilizadorRepository,
                          SenhorioRepository senhorioRepository,
                          EstudanteRepository estudanteRepository
    ) {
        this.utilizadorRepository = utilizadorRepository;
        this.senhorioRepository = senhorioRepository;
        this.estudanteRepository = estudanteRepository;
    }

    @PostMapping("/signin")
    public ResponseEntity<?> signIn(@RequestBody Utilizador utilizador) {
        var email = utilizador.getEmail();
        var password = utilizador.getPassword();

        var user = this.utilizadorRepository.findByEmail(email);
        if(!user.isPresent()) {
            var errorResponse = new ErrorResponse();
            errorResponse.setStatus(400);
            errorResponse.setMessage("Email não registrado, tente criar uma conta!");
            return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);
        }

        if(!(user.get().getPassword().equals(password))) {
            var errorResponse = new ErrorResponse();
            errorResponse.setStatus(400);
            errorResponse.setMessage("Email/Senha errada");
            return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);
        }

        if (user.get().getType().equals(UserType.ESTUDANTE.toString())) {
            var estudante = this.estudanteRepository.findByEmail(email);
            if (!estudante.isPresent()) {
                var errorResponse = new ErrorResponse();
                errorResponse.setStatus(400);
                errorResponse.setMessage("Email não registrado, tente criar uma conta!");
                return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);
            }
            var estudanteAuthResponse = new EstudanteAuthResponse(
                    user.get().getUsername(),
                    user.get().getEmail(),
                    user.get().getType()
            );

            var estudanteResponse = new EstudanteResponse();
            estudanteResponse.setId(estudante.get().getId());
            estudanteResponse.setNome(estudante.get().getNome());
            estudanteResponse.setEmail(estudante.get().getEmail());
            estudanteResponse.setTelefone(estudante.get().getTelefone());
            estudanteResponse.setPassport(estudante.get().getPassport());
            estudanteResponse.setCartaodecidadao(estudante.get().getCartaoDeCidadao());
            estudanteResponse.setDatadenascimento(estudante.get().getDataDeNascimento());

            estudanteAuthResponse.setEstudanteData(estudanteResponse);

            return ResponseEntity.ok().body(estudanteAuthResponse);

        }else if (user.get().getType().equals(UserType.SENHORIO.toString())) {

            var senhorio = this.senhorioRepository.findByEmail(email);
            if (!senhorio.isPresent()) {
                var errorResponse = new ErrorResponse();
                errorResponse.setStatus(400);
                errorResponse.setMessage("Email não registrado, tente criar uma conta!");
                return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);
            }
            var senhorioAuthResponse = new SenhorioAuthResponse(
                    user.get().getUsername(),
                    user.get().getEmail(),
                    user.get().getType()
            );

            var senhorioResponse = new SenhorioResponse();
            senhorioResponse.setId(senhorio.get().getId());
            senhorioResponse.setNome(senhorio.get().getNome());
            senhorioAuthResponse.setEmail(senhorio.get().getEmail());
            senhorioResponse.setTelefone(senhorio.get().getTelefone());


            senhorioAuthResponse.setSenhorioData(senhorioResponse);

            return ResponseEntity.ok().body(senhorioAuthResponse);


        }

        var errorResponse = new ErrorResponse();
        errorResponse.setStatus(400);
        errorResponse.setMessage("Email/Senha errado");
        return ResponseEntity.status(errorResponse.getStatus()).body(errorResponse);

    }

}