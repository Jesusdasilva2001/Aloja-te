package pt.iade.alojate.dto.response;

public class SuccessResponse extends StatusResponse {
}
