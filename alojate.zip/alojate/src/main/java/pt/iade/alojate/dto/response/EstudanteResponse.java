package pt.iade.alojate.dto.response;

public class EstudanteResponse {

    private Long id;
    private String nome;
    private String email;
    private Long telefone;
    private String passport;
    private String cartaodecidadao;
    private String datadenascimento;


    public EstudanteResponse(Long id, String nome, String email, Long telefone, String passport, String cartaodecidadao, String datadenascimento) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.telefone = telefone;
        this.passport = passport;
        this.cartaodecidadao = cartaodecidadao;
        this.datadenascimento = datadenascimento;
    }

    public EstudanteResponse() {}

    public Long getId() {

        return id;
    }

    public void setId(Long id) {

        this.id = id;
    }

    public String getName() {

        return nome;
    }

    public void setNome(String nome) {

        this.nome = nome;
    }

    public String getEmail() {

        return email;
    }

    public void setEmail(String email) {

        this.email = email;
    }

    public Long getTelefone() {

        return telefone;
    }

    public void setTelefone(Long telefone) {

        this.telefone = telefone;
    }

    public String getPassport() {

        return passport;
    }

    public void setPassport(String passport) {

        this.passport = passport;
    }

    public String getCartaodecidadao() {

        return cartaodecidadao;
    }

    public void setCartaodecidadao(String cartaodecidadao) {

        this.cartaodecidadao = cartaodecidadao;
    }

    public String getDatadenascimento() {

        return datadenascimento;
    }

    public void setDatadenascimento(String datadenascimento) {

        this.datadenascimento = datadenascimento;
    }



}
