package pt.iade.alojate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pt.iade.alojate.models.Senhorio;

import java.util.Optional;

public interface SenhorioRepository extends JpaRepository<Senhorio, Long> {

    Optional<Senhorio> findByNome(String name);
    Optional<Senhorio> findByEmail(String email);
    Optional<Senhorio> findByTelefone(Long telefone);

}
