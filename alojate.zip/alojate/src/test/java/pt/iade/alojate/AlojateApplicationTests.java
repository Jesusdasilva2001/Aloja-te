package pt.iade.alojate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlojateApplicationTests {

	@Test
	void contextLoads() {
	}

}
